
#ifndef HW3_MALLOCREPLACE_TIMETEST_H
#define HW3_MALLOCREPLACE_TIMETEST_H

void testAllocateTime();
void testDeallocateTime();

#endif //HW3_MALLOCREPLACE_TIMETEST_H
