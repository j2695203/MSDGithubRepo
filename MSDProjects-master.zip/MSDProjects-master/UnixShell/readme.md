# Unix Shell

As you might have guessed, using C++ and POSIX calls through C, this is my own, homebrew shell program, complete with I/O redirection, pipes, "cd", environment variables, background commands, and tab completion.  
