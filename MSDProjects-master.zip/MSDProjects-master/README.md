# MSDProjects

This is a sampling of the various projects I worked on in my time as a student at the University of Utah's Masters of Software Development program.  
