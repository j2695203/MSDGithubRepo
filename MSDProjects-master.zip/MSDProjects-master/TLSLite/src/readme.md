# TLS Lite

As the name implies, I was able to successfully implement a simplistic, rudimentary version of the Transport Layer Security protocol, wherein a client and a server would perform the appropriate handshakes, the server would send a file in two parts (to simulate the message caps for TLS messages), and the client would receive and decrypt the file, reporting success or failure appropriately.

Please run the client and server files separately, with the server activated first.  

(Note:  the public/private keys in this repository are exclusively used for this assignment, and no other purposes.)  
