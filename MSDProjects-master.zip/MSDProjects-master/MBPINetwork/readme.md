# D3 Visualizations

This was a team project wherein we attempted to provide a visualization of various fictional teams and how people of different Myers-Briggs personality types may be more or less likeliy to team up with other types.  

To observe the visualization, I recommend downloading the files, running a Python webserver:  

    python3 -m http.server 
    
And then accessing localhost:8000.  
