# Encrypted File System

Using OSXFuse, I implemented a rudimentary encrypted file system that can create, open, read, write, and get attributes for encrypted files within a specific directory.  

In order to start the program, please run "/usr/local/bin/python3 encfs.py test/ mountpoint" with the password "password".

Then, in another terminal window, attempt to access the mountpoint/ files, as indicated by the assignment instructions.
