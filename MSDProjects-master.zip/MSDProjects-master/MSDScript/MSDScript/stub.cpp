//
//  stub.cpp
//  HW2ArithmeticCalculator
//
//  Created by Jonathan Sullivan on 1/21/20.
//  Copyright © 2020 Jonathan Sullivan. All rights reserved.
//

#define CATCH_CONFIG_RUNNER

#include "catch.hpp"
