# MSD Script

This project is the work of the entire semester of my Software Engineering class.  The purpose was to build, from the very ground up, a program that could take in basic expressions and return appropriate results.  

For a full explanation and installation instructions, please take a look at the [user manual](https://github.com/jcsullivan/MSDProjects/blob/master/MSDScript/MSDScript%20Manual.pdf)
