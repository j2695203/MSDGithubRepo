//
//  run.h
//  In Class Tests
//
//  Created by Jonathan Sullivan on 1/21/20.
//  Copyright © 2020 Jonathan Sullivan. All rights reserved.
//

#ifndef run_h
#define run_h

#include <stdio.h>

#endif /* run_h */

extern bool run_tests(void);
