//
//  main.cpp
//  HW1_MSDscriptCommandLine
//
//  Created by Jinny Jeng on 1/16/23.
//

#include <iostream>
#include "cmdline.hpp"

int main(int argc, const char * argv[]) {
    use_arguments(argc, argv);
    return 0;
}
