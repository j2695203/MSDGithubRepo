//
//  cmdline.hpp
//  HW1_MSDscriptCommandLine
//
//  Created by Jinny Jeng on 1/16/23.
//

#ifndef cmdline_hpp
#define cmdline_hpp

#include <stdio.h>
#include <iostream>

#include "catch.h"

void use_arguments(int argc, const char * argv[]);

#endif /* cmdline_hpp */
