//
//  main.cpp
//  HW2_ExpressionClasses
//
//  Created by Jinny Jeng on 1/17/23.
//

#include <iostream>
#include "expr.hpp"
#include "cmdline.hpp"
#include <cassert>

#include "catch.h"


int main(int argc, const char * argv[]) {
    
    use_arguments(argc, argv);
    
    return 0;;
    
}
